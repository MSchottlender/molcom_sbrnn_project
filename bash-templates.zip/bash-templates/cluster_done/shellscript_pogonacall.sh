#!/bin/sh
echo "Parameters:"
echo "$p1"
echo "$p2"
echo "$p3"
echo "Print JobID and Hostname"
echo $JOB_ID
echo $HOSTNAME

# Important: Only use one core for external python librarys. This seems to be enough for scipy, numpy, skimage and many others.
# However, does not ensure that only one core is used in any python script, so additional testing may be needed. 
#export MKL_NUM_THREADS=1
#export NUMEXPR_NUM_THREADS=1
#export OMP_NUM_THREADS=1

# if using anaconda and conda environments, switch into the environment, e.g., with
 source ~/anaconda3/bin/activate

. $HOME/.bash_profile

# call you python program and pass the parameters
echo "Now start pogona run # $JOB_ID. Below comes the output."
#which python3
#python3 sim_chemical_reaction_cr.py chemical_reaction_cr.json
pogona --config $p1_$p2.conf.yaml --openfoam-cases-path ~/pogona/pogona-openfoam-cases/ --results-dir ./sim-result-$p2/

# move the logfiles to cluster_done directory
mkdir -p ./cluster_done
find .  -maxdepth 1 -type f -name "*$JOB_ID" -exec mv -t ./cluster_done/ {} +

exit
