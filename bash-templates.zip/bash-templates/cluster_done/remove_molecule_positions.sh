#!/bin/bash

a=$(($1-1))

for i in $(eval echo "{0..$a}")
do
	rm -r sim-result-$i/molecule_positions/
done

