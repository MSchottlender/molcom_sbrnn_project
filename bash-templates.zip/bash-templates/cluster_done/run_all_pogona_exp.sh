#!/bin/bash

a=$(($2-1))

for ((i=3;i<=$a;i+=4))
do
    pogona --config $1_$(($i-3)).conf.yaml --openfoam-cases-path ~/pogona/pogona-openfoam-cases/ --results-dir ./sim-result-$(($i-3))/
    pogona --config $1_$(($i-2)).conf.yaml --openfoam-cases-path ~/pogona/pogona-openfoam-cases/ --results-dir ./sim-result-$(($i-2))/
    pogona --config $1_$(($i-1)).conf.yaml --openfoam-cases-path ~/pogona/pogona-openfoam-cases/ --results-dir ./sim-result-$(($i-1))/
    pogona --config $1_$i.conf.yaml --openfoam-cases-path ~/pogona/pogona-openfoam-cases/ --results-dir ./sim-result-$i/
done

