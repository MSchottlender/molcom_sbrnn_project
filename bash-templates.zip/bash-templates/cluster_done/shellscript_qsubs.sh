#!/bin/sh

#qsub  -cwd -q all.q@compute-1-1.local -v start="${STARTVAR}",step="10",cas="3" start_simulation_pythoncall.sh

# define alias to be used for block-comments
#lias BEGINCOMMENT="if [ ]; then"
#alias ENDCOMMENT="fi"



# first trials where done on SEM and TECNICK data.
#for MYPAR1 in  {0..2} # equal to 0 1 2 
#do
#  echo "${MYPAR1}"
for MYPAR2 in  {0..2}
do
    echo "${MYPAR2}"
    sleep 0.05
    qsub -cwd -pe smp "1" shellscript_pogonacall.sh
#    qsub  -cwd  -v p1="${MYPAR1}",p2="${MYPAR1}",p3="42" shellscript_pythoncall.sh
done
#done


exit
