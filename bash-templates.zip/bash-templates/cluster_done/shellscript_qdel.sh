#!/bin/bash

a=$(($1-1))

b=$(($2))

for i in $(eval echo "{$a..$b}")
do
	qdel $i
done

