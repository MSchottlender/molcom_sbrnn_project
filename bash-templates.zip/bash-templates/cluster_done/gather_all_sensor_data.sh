#!/bin/bash

a=$(($1-1))

mkdir -p all-sensor-data

for i in $(eval echo "{0..$a}")
do
	cp sim-result-$i/sensor_data/sensor\[sensor\].csv all-sensor-data/sensor-data-$i.csv
done

